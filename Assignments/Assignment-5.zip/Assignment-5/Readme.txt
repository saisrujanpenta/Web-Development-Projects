OUR PROJECT

Company Name: FoodX

FoodX is an organization targetting the companies around the world, helping them in organizing their social 
and seasonal events. We provide catering services and organize the workplaces in a better way aesthitically 
and ergonomically. Our website showcases all the services that we provide and an option to connect with us 
and discuss the deals we offer. We have wide range of third party providers whom we connect with the 
companies.


Bootstrap components

1.	Navbar
2.	Dropdown
3.	Buttons
4.	Cards
5.	Carousel
6.	Progress Bar
7. 	Accordion
8. 	Modal
9. 	Tooltip
10.	Circular Image
