import React from "react";

function Jobs() {
  return (
    <h1>Jobs Page</h1>
  );
}

export default Jobs;